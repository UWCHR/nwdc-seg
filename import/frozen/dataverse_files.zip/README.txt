Folders and Files explained

----"October FOIA Production" folder includes all the files the Immigration and Refugee Clinical Program at the Harvard Law School obtained through FOIA in 2023:
1. SRMS data on solitary confinement in the U.S. immigration detention facilities from 2018 to 2023, 
2. quarterly reports,
3. CRCL expert reports.

----"Analysis" folder includes:
1. 2019_2023_daily_detention_confinement - data used for graphic 4, combines average daily solitary confinement (FOIA data) and detention population (downloaded from https://www.ice.gov/detain/detention-management)
2. 2022_2023_FOIA_confinement_vulnerable - FOIA quarterly confinement stats for vulnerable people derived from the SRMS data, used for graphics 2 and 3
3. 2022_2023_ICE_quarterly_confinement_vulnerable - data downloaded from https://www.ice.gov/detain/detention-management, used for graphics 2 and 3
4. data prep - code used to prepare data for analysis
5. replication_code - code used for analysis
6. srms_data - SRMS data produced with the data_prep code, that was used in analysis

